#' Knapsack problem
#'
#' This packages includes several algorithms to solve the knapsack problem.
#' 
#' @docType package
#'
#' @author Ahmet Akdeve \email{ahmak554@student.liu.se}
#' @author Zhixuan Duan \email{darinstu999@gmail.com}
#'
#' @name fastcomplex
#' 
NULL
